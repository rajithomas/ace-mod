       01 H30ISGASAR.
        05 Service-ID           PIC X(10).
        05 Channel-ID           PIC X(5).
        05 Terminal-ID          PIC X(16).
        05 Channel-TXN          PIC X(12).
        05 User-ID              PIC X(4).
        05 Input-Branch         PIC X(4).
        05 REQDATE              PIC X(26).
        05 EQDATE               PIC X(10).
        05 HISNBH               PIC X(1).
        05 Error-Code           PIC X(1).
        05 Error-Message        PIC X(37).
        05 Error-Description    PIC X(132).
        05 Host-Date-Time       PIC X(26).
        05 ACCOUNT-NUMBER       PIC X(13).
        05 QATAR-ID             PIC X(15).
        05 GLOBAL-ID            PIC X(15).
        05 CUSTOMER-MNMONC      PIC X(6).
        05 CUSTOMER-LOC         PIC X(3).
        05 CUSTOMER-BASIC       PIC X(6).
        05 INQUIRY-TYPE         PIC X(2).
        05 ITERATION-NUMBER     PIC X(2).
        05 END-OF-DATA          PIC X(1).
        05 AccountData OCCURS 20 TIMES.
           10 GlobalID          PIC X(15).
           10 QATAR-ID          PIC X(15).
           10 CUSTOMER-MNMONC   PIC X(5).
           10 CUSTOMER-LOC      PIC X(3).
           10 CUSTOMER-BASIC    PIC X(6).
           10 CUSTOMER-TYPE     PIC X(2).
           10 CUST-NAME         PIC X(35).
           10 CUST-AR-NAME      PIC X(35).
           10 CUST-Branch       PIC X(4).
           10 ACCOUNT-NUMBER    PIC X(13).
           10 ACCOUNT-TYPE      PIC X(2).
           10 ACCOUNT-NAME      PIC X(13).
           10 ACCOUNT-CCY            PIC X(3).
           10 ACCOUNT-BALANCE        PIC X(15).
           10 ERROR-FILLER      PIC X(1).
           10 ACCOUNT-CLOSED         PIC X(1).
           10 ACCOUNT-BLOCKED        PIC X(1).
           10 ACCOUNT-DORMANT        PIC X(1).
           10 ACCOUNT-DECEASED       PIC X(1).
           10 AC-TYPE-DESC           PIC X(35).



